package hg.party.dao.downlistdao;

import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;

import com.dt.springjdbc.dao.impl.PostgresqlDaoImpl;

import hg.party.entity.party.Hg_Value_Attribute_Info;


@Component(immediate = true,service = DownListDao.class)
public class DownListDao  extends PostgresqlDaoImpl<Hg_Value_Attribute_Info>{
	public List<Hg_Value_Attribute_Info> findByasdasdId(String id){
		int Id = Integer.parseInt(id);
		String sql = "select * from Hg_Value_Attribute_Info where id=? ";
		RowMapper<Hg_Value_Attribute_Info> rowMapper = BeanPropertyRowMapper.newInstance(Hg_Value_Attribute_Info.class);
		return this.jdbcTemplate.query(sql, rowMapper,Id);
	}
	
	//获取驳回理由
	public List<Hg_Value_Attribute_Info> reasson(){
		String sql = "SELECT * FROM hg_value_attribute_info "+
					"WHERE resources_type = 'reason' ";
		RowMapper<Hg_Value_Attribute_Info> rowMapper = BeanPropertyRowMapper.newInstance(Hg_Value_Attribute_Info.class);
		return this.jdbcTemplate.query(sql, rowMapper);
		
	}
	//查询否有重复
	public List<Hg_Value_Attribute_Info> repeat(String val,String type){
		String sql = "SELECT * from hg_value_attribute_info "+
					 "WHERE resources_value =? "+
					 "and resources_type =? ";
		RowMapper<Hg_Value_Attribute_Info> rowMapper = BeanPropertyRowMapper.newInstance(Hg_Value_Attribute_Info.class);
		return this.jdbcTemplate.query(sql, rowMapper,val,type);
	}
	
}

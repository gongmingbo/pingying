package hg.party.dao.party;


import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.aspectj.weaver.NewConstructorTypeMunger;
import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;
import org.osgi.service.component.annotations.Component;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

import com.dt.springjdbc.dao.impl.PostgresqlDaoImpl;

import hg.party.entity.party.MeetingPlan;
import hg.party.entity.toDoList.Experience;

/**
 * 文件名称： party<br>
 * 创建人 　： Yu Jiang Xia<br>
 * 创建日期： 2018年1月2日下午5:21:55<br>
 */
@Component(immediate = true,service = PartyMeetingPlanInfoDao.class)
public class PartyMeetingPlanInfoDao extends PostgresqlDaoImpl<MeetingPlan>{
	Logger logger=Logger.getLogger(PartyMeetingPlanInfoDao.class);
	//根据会议id查询
	public List<MeetingPlan> meetingId(String meetingid){
		String sql = "SELECT * FROM hg_party_meeting_plan_info "+
					"WHERE meeting_id= ? ";
		RowMapper<MeetingPlan> rowMapper = BeanPropertyRowMapper.newInstance(MeetingPlan.class);
		return this.jdbcTemplate.query(sql, rowMapper,meetingid);
	}
	//上传心得编辑
	public List<Map<String, Object>> experience(String meeting, String userId){
		String sql = "SELECT * FROM hg_party_learning_experience "+
					"WHERE meeting_id=? "+
					"AND participant_id=? ";
		return this.jdbcTemplate.queryForList(sql,meeting,userId);
	}
	//修改心得
	public void updateHeart(String content,String meetingId,String userId){
		String sql = "UPDATE hg_party_learning_experience SET experience_content=? "+
					"WHERE meeting_id=? "+
					"AND participant_id=? ";
		jdbcTemplate.update(sql,content,meetingId,userId);
	}
	
	//根据会议id和用户id修改用户该会议的查看状态
	public void findByMeetingStu(String userId,String meetingId){
		String sql="UPDATE hg_party_meeting_member_info SET check_status='已查看' WHERE meeting_id= ? AND participant_id= ? ";
		//this.jdbcTemplate.execute(sql);
		jdbcTemplate.update(sql,meetingId,userId);
	}
	//根据登录人id查询会议id
	public List<MeetingPlan> meeting_id(String userId){
		String sql = "SELECT * from hg_party_meeting_plan_info "+
					"WHERE check_person= ? ";
		RowMapper<MeetingPlan> rowMapper = BeanPropertyRowMapper.newInstance(MeetingPlan.class);
		return this.jdbcTemplate.query(sql, rowMapper,userId);
	}
	
	/**查询二级党委list */
	public List<String> findOrganization_id(){
		String sql = "select organization_id from hg_party_meeting_plan_info group by organization_id";
		return jdbcTemplate.queryForList(sql,String.class);
	}
	/**查询会议主题list */
	public List<String> findMeeting_type(){
		String sql = "select meeting_type from hg_party_meeting_plan_info group by meeting_type";
		return jdbcTemplate.queryForList(sql,String.class);
	}
	/**查询会议类型list */
	public List<String> findMeeting_theme(){
		String sql = "select meeting_theme from hg_party_meeting_plan_info group by meeting_theme";
		return jdbcTemplate.queryForList(sql,String.class);
	}
	//aa
	public List<Map<String, Object>> find(String starDdate,String endDate,String meetType,String theme,String seconedId,String branchId,String checkState){
		String sql="select cc.*,cus.user_name as check_person_org_name from "+
			       "(SELECT tt.*,us.user_name as check_person_name FROM "+
			       "(SELECT plan.task_status as plan_state, (select org_name from hg_party_org WHERE org_id=plan.organization_id) as branch_name,"+
				   "(select org_name from hg_party_org WHERE org_id=(SELECT org_parent FROM hg_party_org WHERE org_id=plan.organization_id) and org_type!='organization' ) as second_name,"+
				   " plan.*,info.release_time from hg_party_meeting_plan_info  as plan ,hg_party_org_inform_info as info";
		    StringBuffer buffer=new StringBuffer(sql);
		    if (!StringUtils.isEmpty(seconedId)&&StringUtils.isEmpty(branchId)) {
		    	buffer.append(" ,hg_party_org as org_o");
			}
		    buffer.append(" WHERE plan.inform_id=info.inform_id");
		    
		    if (!StringUtils.isEmpty(starDdate)&&StringUtils.isEmpty(endDate)) {
				buffer.append(" AND plan.start_time>'"+starDdate+" 00:00:00' and plan.start_time<'"+starDdate+" 24:00:00'");
			}
		    if (!StringUtils.isEmpty(starDdate)&&!StringUtils.isEmpty(endDate)) {
				buffer.append(" AND plan.start_time>'"+starDdate+" 00:00:00' and plan.start_time<'"+endDate+" 24:00:00'");
			}
		    if (StringUtils.isEmpty(starDdate)&&!StringUtils.isEmpty(endDate)) {
				buffer.append(" AND plan.start_time>'"+endDate+" 00:00:00' and plan.start_time<'"+endDate+" 24:00:00'");
			}
		    if (!StringUtils.isEmpty(meetType)) {
		    	buffer.append(" and plan.meeting_type='"+meetType+"'");
			}
		    if (!StringUtils.isEmpty(theme)) {
		    	buffer.append(" and plan.meeting_theme like '%"+theme+"%'");
			}
		    if (!StringUtils.isEmpty(seconedId)&&!StringUtils.isEmpty(branchId)) {
		    	buffer.append(" AND plan.organization_id='"+branchId+"'");
			}
		    if (!StringUtils.isEmpty(seconedId)&&StringUtils.isEmpty(branchId)) {
		    	buffer.append(" and (org_o.org_parent='"+seconedId+"'  or org_o.org_id='"+seconedId+"') and plan.organization_id=org_o.org_id");
			}
		    if (!StringUtils.isEmpty(checkState)) {
		    	if ("t".equals(checkState)) {
		    		buffer.append(" and plan.check_person_org is not null");
				}else {
					buffer.append(" and plan.check_person_org is null");
				}
			}
		    buffer.append(" ) as tt LEFT OUTER JOIN hg_users_info as us"+
	                      " on tt.check_person=us.user_id ) as cc LEFT OUTER JOIN hg_users_info as cus"+
	                      " on cc.check_person_org=cus.user_id");
//		    logger.info(buffer.toString());
		    return jdbcTemplate.queryForList(buffer.toString());
	}
	//aa0统计条数
	public int MeetingSun(String userName,String seconedId,String branchId,String orgType,String orgId){
		String sql = "";
		int sun = 0;
		if("organization".equals(orgType)){
			 sql = "SELECT count(*) FROM hg_party_meeting_plan_info AS meet "+
					"LEFT JOIN hg_party_meeting_member_info AS mem  "+
					"ON meet.meeting_id=mem.meeting_id  "+
					"LEFT JOIN hg_users_info AS use  "+
					"ON mem.participant_id=use.user_id  "+
					"LEFT JOIN hg_party_org AS org  "+
					"ON use.user_department_id=org.org_id  "+
					"LEFT JOIN hg_party_org AS orgg  "+
					"ON org.org_parent=orgg.org_id  "+
					"WHERE use.user_name LIKE ?  "+
					"AND orgg.org_name LIKE ? "+
					"AND org.org_name LIKE ? ";
			 List<Map<String, Object>> count = jdbcTemplate.queryForList(sql,"%"+userName+"%","%"+seconedId+"%","%"+branchId+"%");
			 sun = Integer.parseInt(count.get(0).get("count").toString());
		}else if("secondary".equals(orgType)){
			sql = "SELECT count(*) FROM hg_party_meeting_plan_info AS meet "+
				"LEFT JOIN hg_party_meeting_member_info AS mem   "+
				"ON meet.meeting_id=mem.meeting_id   "+
				"LEFT JOIN hg_users_info AS use  "+ 
				"ON mem.participant_id=use.user_id   "+
				"LEFT JOIN hg_party_org AS org   "+
				"ON use.user_department_id=org.org_id   "+
				"LEFT JOIN hg_party_org AS orgg   "+
				"ON org.org_parent=orgg.org_id   "+
				"WHERE use.user_name LIKE ?  "+ 
				"AND orgg.org_id=? "+
				"AND org.org_name LIKE ? ";
			List<Map<String, Object>> count = jdbcTemplate.queryForList(sql,"%"+userName+"%",orgId,"%"+branchId+"%");
			sun = Integer.parseInt(count.get(0).get("count").toString());
		}else if("branch".equals(orgType)){
			sql = "SELECT count(*) FROM hg_party_meeting_plan_info AS meet "+
				"LEFT JOIN hg_party_meeting_member_info AS mem   "+
				"ON meet.meeting_id=mem.meeting_id   "+
				"LEFT JOIN hg_users_info AS use  "+ 
				"ON mem.participant_id=use.user_id   "+
				"LEFT JOIN hg_party_org AS org   "+
				"ON use.user_department_id=org.org_id   "+
				"LEFT JOIN hg_party_org AS orgg  "+ 
				"ON org.org_parent=orgg.org_id   "+
				"WHERE use.user_name LIKE ?  "+ 
				"AND meet.organization_id=? ";
			List<Map<String, Object>> count = jdbcTemplate.queryForList(sql,"%"+userName+"%",orgId);
			sun = Integer.parseInt(count.get(0).get("count").toString());
		}
		return sun;
	}
	//aa1 人员会议统计查询
	public List<Map<String, Object>> userMeetingCount(String userName,String seconedId,String branchId,String orgType,String orgId){
		String sql = "";
		List<Map<String, Object>> listObj = null;
		if("organization".equals(orgType)){
			sql = "SELECT *,orgg.org_name AS org_names,org.org_name AS org_nam FROM hg_party_meeting_plan_info AS meet "+
					"LEFT JOIN hg_party_meeting_member_info AS mem  "+
					"ON meet.meeting_id=mem.meeting_id  "+
					"LEFT JOIN hg_users_info AS use  "+
					"ON mem.participant_id=use.user_id  "+
					"LEFT JOIN hg_party_org AS org  "+
					"ON use.user_department_id=org.org_id  "+
					"LEFT JOIN hg_party_org AS orgg  "+
					"ON org.org_parent=orgg.org_id  "+
					"WHERE use.user_name LIKE ?  "+
					"AND orgg.org_name LIKE ? "+
					"AND org.org_name LIKE ? "+
					"ORDER BY meet.start_time ";
			listObj = jdbcTemplate.queryForList(sql,"%"+userName+"%","%"+seconedId+"%","%"+branchId+"%");
		}else if("secondary".equals(orgType)){
			sql = "SELECT *,orgg.org_name AS org_names,org.org_name AS org_nam FROM hg_party_meeting_plan_info AS meet "+
				"LEFT JOIN hg_party_meeting_member_info AS mem   "+
				"ON meet.meeting_id=mem.meeting_id   "+
				"LEFT JOIN hg_users_info AS use  "+ 
				"ON mem.participant_id=use.user_id   "+
				"LEFT JOIN hg_party_org AS org   "+
				"ON use.user_department_id=org.org_id   "+
				"LEFT JOIN hg_party_org AS orgg   "+
				"ON org.org_parent=orgg.org_id   "+
				"WHERE use.user_name LIKE ?  "+ 
				"AND orgg.org_id=? "+
				"AND org.org_name LIKE ? "+
				"ORDER BY meet.start_time";
			listObj = jdbcTemplate.queryForList(sql,"%"+userName+"%",orgId,"%"+branchId+"%");
		}else if("branch".equals(orgType)){
			sql = "SELECT *,orgg.org_name AS org_names,org.org_name AS org_nam FROM hg_party_meeting_plan_info AS meet "+
					"LEFT JOIN hg_party_meeting_member_info AS mem   "+
					"ON meet.meeting_id=mem.meeting_id   "+
					"LEFT JOIN hg_users_info AS use   "+
					"ON mem.participant_id=use.user_id   "+
					"LEFT JOIN hg_party_org AS org   "+
					"ON use.user_department_id=org.org_id   "+
					"LEFT JOIN hg_party_org AS orgg   "+
					"ON org.org_parent=orgg.org_id  "+ 
					"WHERE use.user_name LIKE ?   "+
					"AND meet.organization_id=? "+
					"ORDER BY meet.start_time";
			listObj = jdbcTemplate.queryForList(sql,"%"+userName+"%",orgId);
		}
		return listObj;
	}
	
	//bb
	public List<Map<String, Object>> find(String starDdate,String endDate,String meetType,String theme,String seconedId,String branchId,int pageSize,int startPage,String checkState){
		String sql= "select cc.*,cus.user_name as check_person_org_name from "+
				    "(SELECT tt.*,us.user_name as check_person_name FROM "+
				    "(SELECT plan.task_status as plan_state, (select org_name from hg_party_org WHERE org_id=plan.organization_id) as branch_name,"+
					"(select org_name from hg_party_org WHERE org_id=(SELECT org_parent FROM hg_party_org WHERE org_id=plan.organization_id) and org_type!='organization' ) as second_name,"+
					" plan.*,info.release_time from hg_party_meeting_plan_info  as plan ,hg_party_org_inform_info as info";
		    StringBuffer buffer=new StringBuffer(sql);
		    if (!StringUtils.isEmpty(seconedId)&&StringUtils.isEmpty(branchId)) {
		    	buffer.append(" ,hg_party_org as org_o");
			}
		    buffer.append(" WHERE plan.inform_id=info.inform_id");
		    if (!StringUtils.isEmpty(starDdate)&&StringUtils.isEmpty(endDate)) {
				buffer.append(" AND plan.start_time>'"+starDdate+" 00:00:00' and plan.start_time<'"+starDdate+" 24:00:00'");
			}
		    if (!StringUtils.isEmpty(starDdate)&&!StringUtils.isEmpty(endDate)) {
				buffer.append(" AND plan.start_time>'"+starDdate+" 00:00:00' and plan.start_time<'"+endDate+" 24:00:00'");
			}
		    if (StringUtils.isEmpty(starDdate)&&!StringUtils.isEmpty(endDate)) {
				buffer.append(" AND plan.start_time>'"+endDate+" 00:00:00' and plan.start_time<'"+endDate+" 24:00:00'");
			}
		    if (!StringUtils.isEmpty(meetType)) {
		    	buffer.append(" and plan.meeting_type='"+meetType+"'");
			}
		    if (!StringUtils.isEmpty(theme)) {
		    	buffer.append(" and plan.meeting_theme like '%"+theme+"%'");
			}
		    if (!StringUtils.isEmpty(seconedId)&&!StringUtils.isEmpty(branchId)) {
		    	buffer.append(" AND plan.organization_id='"+branchId+"'");
			}
		    if (!StringUtils.isEmpty(seconedId)&&StringUtils.isEmpty(branchId)) {
		    	buffer.append(" and (org_o.org_parent='"+seconedId+"'  or org_o.org_id='"+seconedId+"') and plan.organization_id=org_o.org_id");
			}
		    if (!StringUtils.isEmpty(checkState)) {
		    	if ("t".equals(checkState)) {
		    		buffer.append(" and plan.check_person_org is not null");
				}else {
					buffer.append(" and plan.check_person_org is null");
				}
			}
		    buffer.append(" order by info.release_time desc limit "+pageSize+" OFFSET "+startPage+"");
		    buffer.append(" ) as tt LEFT OUTER JOIN hg_users_info as us"+
		                  " on tt.check_person=us.user_id ) as cc LEFT OUTER JOIN hg_users_info as cus"+
		                  " on cc.check_person_org=cus.user_id");
//		    logger.info(buffer.toString());
//		    System.out.println(buffer.toString());
		    return jdbcTemplate.queryForList(buffer.toString());
	}
	//bb1
	public List<Map<String, Object>> userMeetingCount(String userName,String seconedId,String branchId,int pageSize,int startPage,String orgType,String orgId){
		String sql = "";
		List<Map<String, Object>> listObject = null;
		if("organization".equals(orgType)){
			sql = "SELECT *,orgg.org_name AS org_names,org.org_name AS org_nam FROM hg_party_meeting_plan_info AS meet "+
					"LEFT JOIN hg_party_meeting_member_info AS mem "+
					"ON meet.meeting_id=mem.meeting_id "+
					"LEFT JOIN hg_users_info AS use "+
					"ON mem.participant_id=use.user_id "+
					"LEFT JOIN hg_party_org AS org "+
					"ON use.user_department_id=org.org_id "+
					"LEFT JOIN hg_party_org AS orgg "+
					"ON org.org_parent=orgg.org_id "+
					"WHERE use.user_name LIKE ? "+
					"AND orgg.org_name LIKE ? "+
					"AND org.org_name LIKE ? "+
					"ORDER BY meet.start_time "+
					"limit ? OFFSET ? ";
			listObject = jdbcTemplate.queryForList(sql,"%"+userName+"%","%"+seconedId+"%","%"+branchId+"%",pageSize,startPage);
		}else if("secondary".equals(orgType)){
			sql = "SELECT *,orgg.org_name AS org_names,org.org_name AS org_nam FROM hg_party_meeting_plan_info AS meet "+
				"LEFT JOIN hg_party_meeting_member_info AS mem   "+
				"ON meet.meeting_id=mem.meeting_id   "+
				"LEFT JOIN hg_users_info AS use   "+
				"ON mem.participant_id=use.user_id   "+
				"LEFT JOIN hg_party_org AS org   "+
				"ON use.user_department_id=org.org_id   "+
				"LEFT JOIN hg_party_org AS orgg   "+
				"ON org.org_parent=orgg.org_id   "+
				"WHERE use.user_name LIKE ?  "+ 
				"AND orgg.org_id=? "+
				"AND org.org_name LIKE ? "+
				"ORDER BY meet.start_time "+
				"limit ? OFFSET ? ";
			listObject = jdbcTemplate.queryForList(sql,"%"+userName+"%",orgId,"%"+branchId+"%",pageSize,startPage);
		}else if("branch".equals(orgType)){
			sql = "SELECT *,orgg.org_name AS org_names,org.org_name AS org_nam FROM hg_party_meeting_plan_info AS meet "+
					"LEFT JOIN hg_party_meeting_member_info AS mem "+
					"ON meet.meeting_id=mem.meeting_id "+
					"LEFT JOIN hg_users_info AS use "+
					"ON mem.participant_id=use.user_id "+
					"LEFT JOIN hg_party_org AS org "+
					"ON use.user_department_id=org.org_id "+
					"LEFT JOIN hg_party_org AS orgg "+
					"ON org.org_parent=orgg.org_id "+
					"WHERE use.user_name LIKE ? "+
					"AND meet.organization_id=? "+
					"ORDER BY meet.start_time "+
					"limit ? OFFSET ? ";
			listObject = jdbcTemplate.queryForList(sql,"%"+userName+"%",orgId,pageSize,startPage);
		}
		return listObject;
	}

	    //根据meetingId查询附件
		public Map<String,Object> findAttachmentByMeetingid(String meetingId){
			String sql="SELECT attachment_url,attachment_name FROM hg_party_attachment WHERE resource_id='"+meetingId+"'";
			try {
				return this.jdbcTemplate.queryForList(sql).get(0);
			} catch (Exception e) {
				return null;
			}
		}
		
		//查询参会人员
		public List<Map<String, Object>> meetingUser(String meeting){
			String sql ="SELECT * from hg_party_group_member_info AS menber JOIN hg_users_info users "+
						"ON menber.participant_id = users.user_id "+
						"WHERE group_id = '"+meeting+"' ";
			return jdbcTemplate.queryForList(sql);
		}
		
		//会议审核导出excel
		public List<Map<String, Object>> approvalExcel(String perm){
			String sql = "SELECT plan.meeting_id as meeting,plan.start_time as start_p,plan.end_time as end_p,* from "+
					"((hg_party_meeting_plan_info as plan "+
					"LEFT JOIN hg_party_meeting_notes_info as note on "+
					"plan.meeting_id = note.meeting_id) LEFT JOIN hg_party_org as org on "+
					"org.org_id = plan.organization_id) LEFT JOIN hg_users_info as usr on "+
					"usr.user_id = auditor "+
					"WHERE org.org_type= ? "+
					"and org.historic is false "+
					"AND (plan.task_status='1' "+
					"OR plan.task_status='3' "+
					"OR plan.task_status='4') "+
					"ORDER BY plan.id ";
			return jdbcTemplate.queryForList(sql,perm);
		}
		//查询发送短信内容
		public List<MeetingPlan> MeetingPlan(String id){
			int Id = Integer.parseInt(id);
			String sql = "SELECT * FROM hg_party_meeting_plan_info WHERE id = ? ";
			RowMapper<MeetingPlan> rowMapper = BeanPropertyRowMapper.newInstance(MeetingPlan.class);
			return this.jdbcTemplate.query(sql, rowMapper,Id);
		}
		
		//获取组织id
		public List<Map<String, Object>> dep(String de){
			String sql = "SELECT * FROM hg_party_org WHERE org_id = ? and historic is false ";
			return jdbcTemplate.queryForList(sql,de);
		}
		
		//二级党组织会议统计
		public List<Map<String, Object>> findSecondMeetingCount(String starDdate,String endDate,String meetType,String theme,String seconedId,String branchId){
			String sql="select cc.*,cus.user_name as check_person_org_name from "+
				       "(SELECT tt.*,us.user_name as check_person_name FROM "+
				       "(SELECT plan.task_status as plan_state, (select org_name from hg_party_org WHERE org_id=plan.organization_id) as branch_name,"+
					   "(select org_name from hg_party_org WHERE org_id=(SELECT org_parent FROM hg_party_org WHERE org_id=plan.organization_id) and org_type!='organization' ) as second_name,"+
					   " plan.*,info.release_time from hg_party_meeting_plan_info  as plan ,hg_party_org_inform_info as info";
			    StringBuffer buffer=new StringBuffer(sql);
			    if (!StringUtils.isEmpty(seconedId)&&StringUtils.isEmpty(branchId)) {
			    	buffer.append(" ,hg_party_org as org_o");
				}
			    buffer.append(" WHERE plan.inform_id=info.inform_id");
			    
			    if (!StringUtils.isEmpty(starDdate)&&StringUtils.isEmpty(endDate)) {
					buffer.append(" AND plan.start_time>'"+starDdate+" 00:00:00' and plan.start_time<'"+starDdate+" 24:00:00'");
				}
			    if (!StringUtils.isEmpty(starDdate)&&!StringUtils.isEmpty(endDate)) {
					buffer.append(" AND plan.start_time>'"+starDdate+" 00:00:00' and plan.start_time<'"+endDate+" 24:00:00'");
				}
			    if (StringUtils.isEmpty(starDdate)&&!StringUtils.isEmpty(endDate)) {
					buffer.append(" AND plan.start_time>'"+endDate+" 00:00:00' and plan.start_time<'"+endDate+" 24:00:00'");
				}
			    if (!StringUtils.isEmpty(meetType)) {
			    	buffer.append(" and plan.meeting_type='"+meetType+"'");
				}
			    if (!StringUtils.isEmpty(theme)) {
			    	buffer.append(" and plan.meeting_theme like '%"+theme+"%'");
				}
			    if (!StringUtils.isEmpty(seconedId)&&!StringUtils.isEmpty(branchId)) {
			    	buffer.append(" AND plan.organization_id='"+branchId+"'");
				}
			    if (!StringUtils.isEmpty(seconedId)&&StringUtils.isEmpty(branchId)) {
			    	buffer.append(" and (org_o.org_parent='"+seconedId+"' or org_o.org_id='"+seconedId+"') and plan.organization_id=org_o.org_id ");
				}
			    buffer.append(" ) as tt LEFT OUTER JOIN hg_users_info as us"+
		                      " on tt.check_person=us.user_id ) as cc LEFT OUTER JOIN hg_users_info as cus"+
		                      " on cc.check_person_org=cus.user_id");
			    return jdbcTemplate.queryForList(buffer.toString());
		}
		
		public List<Map<String, Object>> findChecKStateById(int id){ 
			String sql="select * from  hg_party_meeting_plan_info as plan "+
                       " where plan.organization_id in (select organization_id from hg_party_meeting_plan_info where id= ? ) "+
                       " and plan.check_person_org is not  null";
			return jdbcTemplate.queryForList(sql, id);
		}
		//人员会议统计查询
//		public List<Map<String, Object>> userMeetingCount(String userName){
//			String sql = "";
//			return this.jdbcTemplate.queryForList(sql);
//		}
		
}

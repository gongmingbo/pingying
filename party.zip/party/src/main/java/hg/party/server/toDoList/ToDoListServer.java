package hg.party.server.toDoList;

import java.util.List;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.dt.springjdbc.dao.impl.PostgresqlQueryResult;

import hg.party.dao.toDoList.ToDoListDao;
/**
 * 文件名称： party<br>
 * 内容摘要： @TODO<br>
 * 创建人 　： XiongZG<br>
 * 创建日期： 2017年12月22日下午4:56:30<br>
 * 版本号　 ： v1.0.0<br>
 * 公司　　 : <br>
 * 修改记录1 <br>
 * 修改日期：<br>
 * 版本号 　：<br>
 * 修改人 　：<br>
 * 修改内容： <br>
 */
@Component(immediate = true, service = ToDoListServer.class)
public class ToDoListServer {

	@Reference
	private ToDoListDao toDoListDao;
	/*分页查询*/
	public PostgresqlQueryResult<Map<String, Object>> pagenation(int pageNo,int pageSize,String sql,String nameId,String nameId2){
		return toDoListDao.postGresqlFindBySql(pageNo,pageSize,sql,nameId,nameId2);
	}
	
	/*查询党员所属组织和支部*/
	public List<Map<String,Object>> findOrgAndGroup(String userId){
		return toDoListDao.findOrgAndGroup(userId);
	}
}

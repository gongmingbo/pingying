package hg.party.unity;

public class ContentTypeConvert {
	private int id;
	private String mark;
	
	public int getId() { return id; }
	public void setId(int id) { this.id = id; }
	public String getMark() { return mark; }
	public void setMark(String mark) { this.mark = mark; }
}

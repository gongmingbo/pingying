package hg.util;

import hg.party.entity.organization.Organization;

import java.util.HashMap;

public class ConstantsKey {
    public static final String ORG_TYPE_ROOT = "organization";
    public static final String ORG_TYPE_SECONDARY = "secondary";
    public static final String ORG_TYPE_BRANCH = "branch";
    
    public static final String ORG_TYPE_Pro = "propaganda";//宣传部
    public static final String ORG_PROPAGANDA = "宣传部";
    
    public static final String SECOND_PARTY = "二级党组织";
    public static final String ORG_PARTY = "组织部";
    public static final String BRANCH_PARTY = "党支部";
    public static final String COMMON_PARTY = "普通党员";
    public static final String OTHER_PARTY = "其他";
    public static final HashMap<String, String > PERMISSION_TO_ORGTYPE = new HashMap<>(); // 权限 - 组织类型对应
    public static final HashMap<String, String > ORGTYPE_TO_PERMISSION = new HashMap<>(); // 组织类型 - 权限对应
    static {
        PERMISSION_TO_ORGTYPE.putIfAbsent(SECOND_PARTY, ORG_TYPE_SECONDARY);
        PERMISSION_TO_ORGTYPE.putIfAbsent(ORG_PARTY, ORG_TYPE_ROOT);
        PERMISSION_TO_ORGTYPE.putIfAbsent(BRANCH_PARTY, ORG_TYPE_BRANCH);
        PERMISSION_TO_ORGTYPE.putIfAbsent(ORG_PROPAGANDA, ORG_TYPE_Pro);

        ORGTYPE_TO_PERMISSION.putIfAbsent( ORG_TYPE_SECONDARY, SECOND_PARTY);
        ORGTYPE_TO_PERMISSION.putIfAbsent(ORG_TYPE_ROOT, ORG_PARTY);
        ORGTYPE_TO_PERMISSION.putIfAbsent(ORG_TYPE_BRANCH, BRANCH_PARTY);
        ORGTYPE_TO_PERMISSION.putIfAbsent(ORG_TYPE_Pro, ORG_PROPAGANDA);
        
    }
}
